import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.io.BufferedWriter;
import java.io.FileWriter;

public class Flight extends JFrame implements ActionListener {
    JPanel p1;
    ImageIcon icon, bgimg, blutik, backimg, exitimg;
    JLabel imglbl, ttl, sl, fl, tl, pl, cl, dl, rl, lcost;
    JRadioButton one, round;
    ButtonGroup b;
    JButton tik, Reset, Invoice, Book, Back, Exit;
    JComboBox type, from, to, day1, month1, day2, month2, person, clas;  
    Font f1, f2, f3, f4;
    String name, phone, email;
    double DestinationCost = 0;
    double totalcost =0;

    Flight()
    {
        super("TravelBro | Flight Booking");
        this.setSize(1280,720);
        this.setLocationRelativeTo(null);
        this.setResizable(false);
        this.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
        
        f1 = new Font("Perpetua", Font.PLAIN, 20);
        f2 = new Font("Aharoni", Font.BOLD, 22);
        f3 = new Font("Franklin Gothic Demi", Font.PLAIN, 16);
        f4 = new Font("Perpetua", Font.PLAIN, 22);

        p1= new JPanel();
        p1.setLayout(null);
        add(p1);

        one= new JRadioButton("One way");
        one.setBounds(695, 180, 150,50);
        one.setContentAreaFilled(false);
        one.setFont(f1);
        one.setFocusable(false);
        one.addActionListener(this);
        
        round= new JRadioButton("Round Trip");
        round.setBounds(1050, 180, 150, 50);
        round.setContentAreaFilled(false);
        round.setFont(f1);
        round.setFocusable(false);
        round.addActionListener(this);
        
        b= new ButtonGroup();
        b.add(one);
        b.add(round);
        p1.add(one);
        p1.add(round);

        backimg = new ImageIcon("Images/back.png");
        Back = new JButton(backimg);
        Back.setBounds(0,580,100,100);
        Back.setFocusable(false);
        Back.setBorder(BorderFactory.createEmptyBorder(0,0,0,0));
        Back.setBorderPainted(false);
        Back.setContentAreaFilled(false);
        Back.setCursor(new Cursor(Cursor.HAND_CURSOR));
        Back.addActionListener(this);
        p1.add(Back);

        ImageIcon exitimg = new ImageIcon("Images/exit2.png");
        Exit = new JButton(exitimg);
        Exit.setBounds(1150,0,100,100);
        Exit.setFocusable(false);
        Exit.setBorder(BorderFactory.createEmptyBorder(0,0,0,0));
        Exit.setBorderPainted(false);
        Exit.setContentAreaFilled(false);
        Exit.setCursor(new Cursor(Cursor.HAND_CURSOR));
        Exit.addActionListener(this);
        p1.add(Exit);

        blutik = new ImageIcon("Images/blutik.png");
        tik = new JButton(blutik);
        tik.setBounds(860,555,50,50);
        tik.setFocusable(false);
        tik.setBorder(BorderFactory.createEmptyBorder(0,0,0,0));
        tik.setBorderPainted(false);
        tik.setContentAreaFilled(false);
        tik.setCursor(new Cursor(Cursor.HAND_CURSOR));
        tik.addActionListener(this);
        p1.add(tik);

        Reset = new JButton("Refresh");
        Reset.setBounds(730, 618, 150, 50);
        Reset.setFont(f2);
        Reset.setForeground(Color.white);
        Reset.setFocusable(false);
        Reset.setBorder(BorderFactory.createEmptyBorder(0,0,0,0));
        Reset.setFocusPainted(true);
        Reset.setContentAreaFilled(false);
        Reset.setCursor(new Cursor(Cursor.HAND_CURSOR));
        Reset.addActionListener(this);
        p1.add(Reset);

        Book = new JButton("Book Now!");
        Book.setBounds(986, 618, 150, 50);
        Book.setFont(f2);
        Book.setForeground(Color.white);
        Book.setFocusable(false);
        Book.setBorder(BorderFactory.createEmptyBorder(0,0,0,0));
        Book.setFocusPainted(true);
        Book.setContentAreaFilled(false);
        Book.setCursor(new Cursor(Cursor.HAND_CURSOR));
        Book.addActionListener(this);
        p1.add(Book);

        //total label
        ttl = new JLabel("Total cost:");
        ttl.setBounds(950,525, 150, 50);
        ttl.setFont(f3);
        p1.add(ttl);

        //type
        String [] t = {"Select your flight type", "Domestic Flight", "International Flight"};
        type= new JComboBox<>(t);
        type.setBounds(680,230,500,40);
        type.setSelectedIndex(0);
        type.addActionListener(this);
        p1.add(type);

        //from label
        fl = new JLabel("From:");
        fl.setBounds(680,285, 150, 50);
        fl.setFont(f3);
        p1.add(fl);
        
        //from box
        String [] f= {"Select location", "Dhaka", "Chittagong"};
        from= new JComboBox<>(f);
        from.setBounds(680, 320, 230, 40);
        from.setSelectedIndex(0);
        from.addActionListener(this);
        p1.add(from);

        //to label
        tl = new JLabel("To:");
        tl.setBounds(950,285, 150, 50);
        tl.setFont(f3);
        p1.add(tl);
        
        //to box
        String [] t1= {"Select flight type first"};
        to= new JComboBox<>(t1);
        to.setBounds(950, 320, 230, 40);
        to.addActionListener(this);
        //to.disable();
        p1.add(to);

        //dep label
        dl = new JLabel("Departing:");
        dl.setBounds(680,365, 150, 50);
        dl.setFont(f3);
        p1.add(dl);

        //dep box day
        day1= new JComboBox<>();
        day1.setBounds(857, 400,55, 40);
        day1.disable();
        day1.addActionListener(this);
        p1.add(day1);

        //dep box month
        String [] m=  {"Select Month", "January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"};
        month1= new JComboBox<String>(m);
        month1.setBounds(680, 400,175, 40);
        month1.setSelectedIndex(0);
        month1.disable();
        month1.addActionListener(this);
        p1.add(month1);


        //ret label
        rl = new JLabel("Returning:");
        rl.setBounds(950,365, 150, 50);
        rl.setFont(f3);
        p1.add(rl);

        //ret box day
        day2= new JComboBox<String>();
        day2.setBounds(1127, 400,55, 40);
        day2.disable();
        day2.addActionListener(this);;
        p1.add(day2);

        //ret box month
        String [] m2=  {"Select Month", "January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"};
        month2= new JComboBox<String>(m);
        month2.setBounds(950, 400,175, 40);
        month2.setSelectedIndex(0);
        month2.disable();
        month2.addActionListener(this);
        p1.add(month2);

        //person label
        pl = new JLabel("Person:");
        pl.setBounds(680,445, 150, 50);
        pl.setFont(f3);
        p1.add(pl);
        //person box
        String [] p= {"Select number of persons", "1", "2", "3", "4", "5"};
        person= new JComboBox<>(p);
        person.setBounds(680, 480, 230, 40);
        person.addActionListener(this);
        p1.add(person);


        //class label
        cl = new JLabel("Class:");
        cl.setBounds(950,445, 150, 50);
        cl.setFont(f3);
        p1.add(cl);
        //class box
        String [] c= {"Select flight class", "Economy", "Business"};
        clas= new JComboBox<>(c);
        clas.setBounds(950, 480, 230, 40);
        clas.addActionListener(this);
        p1.add(clas);

        lcost = new JLabel("00000.00 BDT");
        lcost.setBounds(1010, 567, 300,30);
        lcost.setFont(f4);
        lcost.setForeground(Color.white);
        p1.add(lcost);


        bgimg = new ImageIcon("Images/flight.png");
        imglbl = new JLabel(bgimg);
        imglbl.setBounds(0,0,1280,720);
        p1.add(imglbl);


        icon = new ImageIcon("Images/Icon.png");
        this.setIconImage(icon.getImage());


        this.setVisible(true);
    }

    public void actionPerformed(ActionEvent e)
    {
        if (e.getSource()==one)
        {
            day1.enable();
            month1.enable();
            day2.disable();
            month2.disable();
        }
        
        else if (e.getSource()==round)
        {
            day1.enable();
            month1.enable();
            day2.enable();
            month2.enable();
        }

        else if (e.getSource()==type)
        {
            int a= type.getSelectedIndex();
            if(a == 0)
            {
                day2.disable();
                month2.disable();
            }
            else if (a == 1)
            {
                to.removeAllItems();;
                String [] tod= {"Select your city", "Cox's Bazar", "Rajshahi", "Barishal", "Jessore"}; 
                for (int i = 0; i <= 4; i++)
                {
                    to.addItem(tod[i]);
                }
                
            }
            else if (a == 2)
            {
                to.removeAllItems();;
                String [] tod= {"Select your destination","Delhi, India", "Bangkok, Thailand", "Doha, Qatar", "Dubai, United Arab Emirates" }; 
                for (int i = 0; i <= 4; i++)
                {
                    to.addItem(tod[i]);
                }
                
            }
        }

        else if(e.getSource()==month2){
            int w= month2.getSelectedIndex();
            if (w == 2){
                day2.removeAllItems();
                for (int i = 0; i <= 28; i++) {
                    day2.addItem(String.valueOf(i));
                }
            }
            else if (w == 4 ||w==6||w==9||w==11){
                day2.removeAllItems();
                for (int i = 0; i <= 30; i++) {
                    day2.addItem(String.valueOf(i));
                }
            }
            else if (w== 1 ||w==3||w==5||w==7||w==8||w==10||w==12){
                day2.removeAllItems();
                for (int i = 0; i <= 31; i++) {
                    day2.addItem(String.valueOf(i));
                }
            }
        }

        else if(e.getSource()==month1){
            int q= month1.getSelectedIndex();
            if (q == 2){
                day1.removeAllItems();
                for (int i = 0; i <= 28; i++) {
                    day1.addItem(String.valueOf(i));
                }
            }
            else if (q == 4 || q==6||q==9||q==11){
                day1.removeAllItems();
                for (int i = 0; i <= 30; i++) {
                    day1.addItem(String.valueOf(i));
                }
            }
            else if (q== 1 || q==3||q==5||q==7 ||q==8||q==10||q==12){
                day1.removeAllItems();
                for (int i = 0; i <= 31; i++) {
                    day1.addItem(String.valueOf(i));
                }
            }
        }

        else if(e.getSource()==Reset){
            this.dispose();
            new Flight();
        }

        else if (e.getSource()==Back){
            this.dispose();
            new Home();
        }

        else if(e.getSource()==tik)
        {
            int p= month1.getSelectedIndex();
            int l= month2.getSelectedIndex();

            if (type.getSelectedIndex()==0||from.getSelectedIndex()==0||to.getSelectedIndex()==0||day1.getSelectedIndex()==0|| month1.getSelectedIndex()==0|| person.getSelectedIndex()==0||clas.getSelectedIndex()==0)
            {
                JOptionPane.showMessageDialog(null,"Please fill in all the credentials", "Flight Booking", 2);
            }
            
            //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
            else if (one.isSelected()) 
            {
                if (p==0||p==1||p==2||p==3||p==4)
                {
                    JOptionPane.showMessageDialog(null, "Select correct month","Invalid month", 3);
                }

                //domestic
                else if (type.getSelectedIndex()==1){
                    
                    //from dhaka
                    if(from.getSelectedIndex()==1){
                        if(to.getSelectedIndex()==1){
                            DestinationCost = 5000;
                        }
                        else if (to.getSelectedIndex()==2){
                            DestinationCost = 3500;
                        }
                        else if (to.getSelectedIndex()==3){
                            DestinationCost = 3000;
                        }
                        else if (to.getSelectedIndex()==4){
                            DestinationCost = 3200;
                        }

                        totalcost = person.getSelectedIndex()*DestinationCost*clas.getSelectedIndex();
                        lcost.setText(""+totalcost+" BDT");
                    }

                    //from chittagong
                    else if (from.getSelectedIndex()==2){
                        if(to.getSelectedIndex()==1){
                            DestinationCost = 7000;
                        }
                        else if (to.getSelectedIndex()==2){
                            DestinationCost = 6300;
                        }
                        else if (to.getSelectedIndex()==3){
                            DestinationCost = 5000;
                        }
                        else if (to.getSelectedIndex()==4){
                            DestinationCost = 6000;
                        }
                        totalcost = person.getSelectedIndex()*DestinationCost*clas.getSelectedIndex();
                        lcost.setText(""+totalcost+" BDT");
                    }

                }
                //international
                else if (type.getSelectedIndex()==2){

                    //from dhaka
                    if(from.getSelectedIndex()==1){
                        if(to.getSelectedIndex()==1){
                            DestinationCost = 16000;
                        }
                        else if (to.getSelectedIndex()==2){
                            DestinationCost = 25000;
                        }
                        else if (to.getSelectedIndex()==3){
                            DestinationCost = 57000;
                        }
                        else if (to.getSelectedIndex()==4){
                            DestinationCost = 43000;
                        }
                        totalcost = person.getSelectedIndex()*DestinationCost*clas.getSelectedIndex();
                        lcost.setText(""+totalcost+" BDT");
                    }
                    //from chittagong
                    else if (from.getSelectedIndex()==2){
                        if(to.getSelectedIndex()==1){
                            DestinationCost = 19000;
                        }
                        else if (to.getSelectedIndex()==2){
                            DestinationCost = 37000;
                        }
                        else if (to.getSelectedIndex()==3){
                            DestinationCost = 60000;
                        }
                        else if (to.getSelectedIndex()==4){
                            DestinationCost = 46000;
                        }
                        totalcost = person.getSelectedIndex()*DestinationCost*clas.getSelectedIndex();
                        lcost.setText(""+totalcost+" BDT");
                    }
                }
            }

            //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
            else if (round.isSelected()){
                if (l==0||l==1||l==2||l==3||l==4)
                {
                    JOptionPane.showMessageDialog(null, "Select correct month","Invalid month", 3);
                }

                //domestic
                else if (type.getSelectedIndex()==1){
                    
                    //from dhaka
                    if(from.getSelectedIndex()==1){
                        if(to.getSelectedIndex()==1){
                            DestinationCost = 5000;
                        }
                        else if (to.getSelectedIndex()==2){
                            DestinationCost = 3500;
                        }
                        else if (to.getSelectedIndex()==3){
                            DestinationCost = 3000;
                        }
                        else if (to.getSelectedIndex()==4){
                            DestinationCost = 3200;
                        }

                        totalcost = person.getSelectedIndex()*DestinationCost*clas.getSelectedIndex()*2;
                        lcost.setText(""+totalcost+" BDT");
                    }
                    //from chittagong
                    else if (from.getSelectedIndex()==2){
                        if(to.getSelectedIndex()==1){
                            DestinationCost = 7000;
                        }
                        else if (to.getSelectedIndex()==2){
                            DestinationCost = 6300;
                        }
                        else if (to.getSelectedIndex()==3){
                            DestinationCost = 5000;
                        }
                        else if (to.getSelectedIndex()==4){
                            DestinationCost = 6000;
                        }
                        totalcost = person.getSelectedIndex()*DestinationCost*clas.getSelectedIndex()*2;
                        lcost.setText(""+totalcost+" BDT");
                    }

                }
                //international
                else if (type.getSelectedIndex()==2){

                    //from dhaka
                    if(from.getSelectedIndex()==1){
                        if(to.getSelectedIndex()==1){
                            DestinationCost = 16000;
                        }
                        else if (to.getSelectedIndex()==2){
                            DestinationCost = 25000;
                        }
                        else if (to.getSelectedIndex()==3){
                            DestinationCost = 57000;
                        }
                        else if (to.getSelectedIndex()==4){
                            DestinationCost = 43000;
                        }
                        totalcost = person.getSelectedIndex()*DestinationCost*clas.getSelectedIndex()*2;
                        lcost.setText(""+totalcost+" BDT");
                    }
                    //from chittagong
                    else if (from.getSelectedIndex()==2){
                        if(to.getSelectedIndex()==1){
                            DestinationCost = 19000;
                        }
                        else if (to.getSelectedIndex()==2){
                            DestinationCost = 37000;
                        }
                        else if (to.getSelectedIndex()==3){
                            DestinationCost = 60000;
                        }
                        else if (to.getSelectedIndex()==4){
                            DestinationCost = 46000;
                        }
                        totalcost = person.getSelectedIndex()*DestinationCost*clas.getSelectedIndex()*2;
                        lcost.setText(""+totalcost+" BDT");
                    }
                }
            }
        }

        else if (e.getSource()== Book)
        {
            if (type.getSelectedIndex()==0||from.getSelectedIndex()==0||to.getSelectedIndex()==0||day1.getSelectedIndex()==0|| month1.getSelectedIndex()==0|| person.getSelectedIndex()==0||clas.getSelectedIndex()==0)
            {
                JOptionPane.showMessageDialog(null,"Please fill in all the credentials", "Flight Booking", 2);
            }
            else {
                try {
                    name = Files.readAllLines(Paths.get("Datas/Current_User_Data.txt")).get(0);
                    phone = Files.readAllLines(Paths.get("Datas/Current_User_Data.txt")).get(1);
                    email = Files.readAllLines(Paths.get("Datas/Current_User_Data.txt")).get(2);

                    FileWriter file = new FileWriter("Datas/Flight_Booking_Info.txt",true);
                    BufferedWriter bw = new BufferedWriter(file);
                    PrintWriter pw = new PrintWriter(bw);

                    pw.println("Flight Ticket");
                    pw.println("Name: "+name);
                    pw.println("Phone: "+phone);
                    pw.println("Email: "+email);
                    pw.println("Flight type: "+ type.getSelectedItem());
                    pw.println("FROM: "+ from.getSelectedItem());
                    pw.println("TO: "+ to.getSelectedItem());
                    pw.println("Number of persons: "+ person.getSelectedItem());
                    pw.println("Class: "+ clas.getSelectedItem());
                    pw.println(DestinationCost);
                    pw.println("Total: "+totalcost);
                    pw.println("~~~~~~~~~~~~~~~~~~");
                    pw.close();

                    FileWriter file1 = new FileWriter("Datas/Flight_Booking_Info_temp.txt",true);
                    BufferedWriter bw1 = new BufferedWriter(file1);
                    PrintWriter pw1 = new PrintWriter(bw1);

                    pw1.println(name);
                    pw1.println(phone);
                    pw1.println(email);
                    pw1.println(from.getSelectedItem());
                    pw1.println(to.getSelectedItem());
                    pw1.println(person.getSelectedItem());
                    pw1.println(clas.getSelectedItem());
                    pw1.println(DestinationCost);
                    pw1.println(totalcost);
                    pw1.close();

                }
                catch (IOException ex) {
                    System.out.println(ex);
                    }
                this.dispose();
                new FlightInvoice();
            }
   
        }

        else if (e.getSource()==Exit){
            try{
                Path path = Paths.get("Datas/Current_User_Data.txt");
                var lines = Files.readAllLines(path);
                lines.removeIf(line->line.contains(""));
                Files.write(path,lines);
            }
            catch (IOException ex){
                System.out.println(ex);
            }
            System.exit(0);
        }

    }
    
}


