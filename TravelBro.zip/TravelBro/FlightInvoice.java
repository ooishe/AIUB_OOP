import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.SimpleDateFormat;
import java.util.Date;


public class FlightInvoice extends JFrame implements ActionListener{

    JPanel p1;
    JLabel imglbl,inv, ldate, qn, des, pr, tt, fl, tl, nl, el;
    JLabel fl1, tl1, qn1, des1,des2, des3, pr1, tt1;
    JLabel l1,l2,l3,l4;
    JButton pay, Exit; 
    ImageIcon icon, bgimg, exitimg;
    Font f1, f2, f3, f4, f5;
    String name, email, from, to, pern, cl, descost, totcost;

    FlightInvoice(){
        super("TravelBro | Flight Invoice");
        this.setSize(600,730);
        this.setLocationRelativeTo(null);
        this.setResizable(false);
        this.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);

        p1= new JPanel();
        p1.setLayout(null);
        add(p1);

        f1 = new Font("Poppins", Font.BOLD, 14);
        f2 = new Font("Franklin Gothic Demi", Font.BOLD, 38);
        f3 = new Font("SansSerif", Font.BOLD, 14);
        f5 = new Font("SansSerif", Font.PLAIN, 14);
        f4 = new Font("Franklin Gothic Demi", Font.PLAIN, 20);

        try {
            name = Files.readAllLines(Paths.get("Datas/Flight_Booking_Info_temp.txt")).get(0);
            email = Files.readAllLines(Paths.get("Datas/Flight_Booking_Info_temp.txt")).get(2);
            from = Files.readAllLines(Paths.get("Datas/Flight_Booking_Info_temp.txt")).get(3);
            to = Files.readAllLines(Paths.get("Datas/Flight_Booking_Info_temp.txt")).get(4);
            pern = Files.readAllLines(Paths.get("Datas/Flight_Booking_Info_temp.txt")).get(5);
            cl = Files.readAllLines(Paths.get("Datas/Flight_Booking_Info_temp.txt")).get(6);
            descost = Files.readAllLines(Paths.get("Datas/Flight_Booking_Info_temp.txt")).get(7);
            totcost = Files.readAllLines(Paths.get("Datas/Flight_Booking_Info_temp.txt")).get(8);

        } catch (IOException e) {
            System.out.println(e);
        }

        inv = new JLabel("INVOICE");
        inv.setBounds(385, 60, 200, 50);
        inv.setFont(f2);
        inv.setForeground(Color.decode("#5579C6"));
        p1.add(inv);

        //current date
        SimpleDateFormat date = new SimpleDateFormat ("MMMM dd, yyyy");
        String currentDate = date.format(new Date());
        ldate = new JLabel(currentDate);
        ldate.setBounds(440,100,200,30);
        ldate.setFont(f3);
        p1.add(ldate);

        nl= new JLabel(name);
        nl.setBounds(425, 140, 200, 30);
        nl.setFont(f3);
        p1.add(nl);

        el= new JLabel(email);
        el.setBounds(365, 160, 200, 30);
        el.setFont(f3);
        p1.add(el);

        fl = new JLabel("From:");
        fl.setBounds(100,140, 150, 50);
        fl.setFont(f3);
        p1.add(fl);

        fl1 = new JLabel(from);
        fl1.setBounds(100,160, 150, 50);
        fl1.setFont(f5);
        p1.add(fl1);

        tl = new JLabel("To:");
        tl.setBounds(100,200, 150, 50);
        tl.setFont(f3);
        p1.add(tl);

        tl1 = new JLabel(to);
        tl1.setBounds(100,220, 200, 50);
        tl1.setFont(f5);
        p1.add(tl1);

        qn = new JLabel("QTY");
        qn.setBounds(90,277, 150, 50);
        qn.setFont(f1);
        p1.add(qn);

        qn1 = new JLabel(pern);
        qn1.setBounds(97,340, 150, 50);
        qn1.setFont(f5);
        p1.add(qn1);

        des = new JLabel("DESCRIPTION");
        des.setBounds(150, 277, 200, 50);
        des.setFont(f1);
        p1.add(des);
        
        des1 = new JLabel(cl+ " class flight" );
        des1.setBounds(150, 340, 200, 50);
        des1.setFont(f5);
        p1.add(des1);
        des2 = new JLabel("with meals provided,");
        des2.setBounds(150, 360, 200, 50);
        des2.setFont(f5);
        p1.add(des2);
        des3 = new JLabel("non-refundable");
        des3.setBounds(150, 380, 200, 50);
        des3.setFont(f5);
        p1.add(des3);

        
        pr = new JLabel("PRICE");
        pr.setBounds(330, 277, 200, 50);
        pr.setFont(f1);
        p1.add(pr);

        pr1 = new JLabel(descost+" BDT");
        pr1.setBounds(320, 340, 200, 50);
        pr1.setFont(f5);
        p1.add(pr1);

        tt = new JLabel("TOTAL");
        tt.setBounds(450, 277, 200, 50);
        tt.setFont(f1);
        p1.add(tt);

        tt1 = new JLabel(totcost+" BDT");
        tt1.setBounds(440, 340, 200, 50);
        tt1.setFont(f5);
        p1.add(tt1);

        l1 = new JLabel("Travel Bro");
        l1.setBounds(70,520,140,50);//40
        l1.setFont(f3);
        p1.add(l1);


        l2 = new JLabel("Commercial Plot-17/1");
        l2.setBounds(70,540,200,50);
        l2.setFont(f5);
        p1.add(l2);

        l3 = new JLabel("Mirpur-2,Dhaka-1216");
        l3.setBounds(70,555,200,50);
        l3.setFont(f5);
        p1.add(l3);

        l4 = new JLabel("www.travelbro.com");
        l4.setBounds(70,570,200,50);
        l4.setFont(f5);
        p1.add(l4);

        pay =new JButton("Proceed Payment");
        pay.setBounds(325, 553, 200, 35);
        pay.setFont(f4);
        pay.setContentAreaFilled(false);
        pay.setForeground(Color.white);
        pay.setFocusPainted(true);
        pay.setFocusable(false);
        pay.setBorder(BorderFactory.createEmptyBorder());
        pay.setCursor(new Cursor(Cursor.HAND_CURSOR));
        pay.addActionListener(this);
        p1.add(pay);

        ImageIcon exitimg = new ImageIcon("Images/exit2.png");
        Exit = new JButton(exitimg);
        Exit.setBounds(10,0,100,100);
        Exit.setFocusable(false);
        Exit.setBorder(BorderFactory.createEmptyBorder(0,0,0,0));
        Exit.setBorderPainted(false);
        Exit.setContentAreaFilled(false);
        Exit.setCursor(new Cursor(Cursor.HAND_CURSOR));
        Exit.addActionListener(this);
        p1.add(Exit);

        bgimg = new ImageIcon("Images/inbg.png");
        imglbl = new JLabel(bgimg);
        imglbl.setBounds(0,0,600,730);
        p1.add(imglbl);


        icon = new ImageIcon("Images/Icon.png");
        this.setIconImage(icon.getImage());

        this.setVisible(true);
    }

    public void actionPerformed (ActionEvent e){
        if (e.getSource()==pay){
            this.dispose();
            new payment();

            try {
                Path path = Paths.get("Datas/Flight_Booking_Info_temp.txt");
                var lines = Files.readAllLines(path);
                lines.removeIf(line->line.contains(""));
                Files.write(path,lines);
    
            } catch (IOException ex) {
                System.out.println(ex);
            }
        }
        else if (e.getSource()== Exit){
            try {
                Path path = Paths.get("Datas/Flight_Booking_Info_temp.txt");
                var lines = Files.readAllLines(path);
                lines.removeIf(line->line.contains(""));
                Files.write(path,lines);
    
            } catch (IOException ex) {
                System.out.println(ex);
            }

            try{
                Path path = Paths.get("Datas/Current_User_Data.txt");
                var lines = Files.readAllLines(path);
                lines.removeIf(line->line.contains(""));
                Files.write(path,lines);
            }
            catch (IOException ex){
                System.out.println(ex);
            }
            System.exit(0);
        }
    }

}