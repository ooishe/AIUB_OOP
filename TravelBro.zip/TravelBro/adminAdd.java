import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.nio.file.Paths;

public class adminAdd extends JFrame implements ActionListener{

    ImageIcon img,iconimg,on,off;
    JLabel imglbl,lfname,llname,lphnnum,lpass,lemail, lbheh, lbhehe;
    JPanel p1;
    JButton submitbtn,backbtn,resetButton;
    JToggleButton showpassButton;
    JTextField tfname,tlname,tphnnum,temail;
    JPasswordField tpass;

    adminAdd(){
        super("TravelBro | Add user");
        this.setSize(1000,700);
        this.setLocationRelativeTo(null);
        this.setResizable(false);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        Font f = new Font("Poppins", Font.BOLD, 16);
        Font f1 = new Font("Aharoni", Font.BOLD, 24);
        Font f2 = new Font("Poppins", Font.BOLD, 14);

        p1 = new JPanel();
        p1.setLayout(null);
        p1.setSize(new Dimension(1000,700));

        lbhehe = new JLabel("\u2302 Home > Admin > Add User");
        lbhehe.setBounds(400,30,500,30);
        lbhehe.setFont(f2);
        p1.add(lbhehe);
        
        lbheh = new JLabel("NEW  USER");
        lbheh.setBounds(400,105,200,30);
        lbheh.setFont(f1);
        p1.add(lbheh);

        lfname = new JLabel("First Name         :");////////////////////////x-100
        lfname.setBounds(450,230,200,30);
        lfname.setFont(f);
        lfname.setForeground(Color.white);
        p1.add(lfname);

        llname = new JLabel("Last Name         :");
        llname.setBounds(450,300,200,30);
        llname.setFont(f);
        llname.setForeground(Color.white);
        p1.add(llname);

        
        lphnnum = new JLabel("Phone Number  :");
        lphnnum.setBounds(450,370,200,30);
        lphnnum.setFont(f);
        lphnnum.setForeground(Color.white);
        p1.add(lphnnum);


        lemail = new JLabel("E- mail               :");
        lemail.setBounds(450,440,200,30);
        lemail.setFont(f);
        lemail.setForeground(Color.white);
        p1.add(lemail);


        lpass = new JLabel("Enter Password :");
        lpass.setBounds(450,510,200,30);
        lpass.setFont(f);
        lpass.setForeground(Color.white);
        p1.add(lpass);


        tfname = new JTextField();
        tfname.setBounds(600,230,300,30);//////////x 350
        tfname.addActionListener(this);
        lfname.setForeground(Color.white);
        p1.add(tfname);

        tlname = new JTextField();
        tlname.setBounds(600,300,300,30);
        tlname.addActionListener(this);
        lfname.setForeground(Color.white);
        p1.add(tlname);

        tphnnum = new JTextField();
        tphnnum.setBounds(600,370,300,30);
        tphnnum.addActionListener(this);
        p1.add(tphnnum);

        temail = new JTextField();
        temail.setBounds(600,440,300,30);
        temail.addActionListener(this);
        p1.add(temail);

        tpass = new JPasswordField();
        tpass.setBounds(600,510,300,30);
        tpass.addActionListener(this);
        p1.add(tpass);


        submitbtn = new JButton("Save User");
        submitbtn.setBounds(800,100,130,40);
        submitbtn.addActionListener(this);
        submitbtn.setFont(f);
        submitbtn.setFocusable(false);
        submitbtn.setBorder(BorderFactory.createEmptyBorder(0,0,0,0));
        submitbtn.setFocusPainted(true);
        submitbtn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        p1.add(submitbtn);

        resetButton = new JButton("RESET");
        resetButton.setBounds(700,100,80,40);
        resetButton.addActionListener(this);
        resetButton.setFont(f2);
        resetButton.setFocusable(false);
        resetButton.setBorder(BorderFactory.createEmptyBorder(0,0,0,0));
        resetButton.setFocusPainted(true);
        resetButton.setContentAreaFilled(false);
        resetButton.setCursor(new Cursor(Cursor.HAND_CURSOR));
        resetButton.setForeground(Color.white);
        p1.add(resetButton);

        backbtn = new JButton("BACK");
        backbtn.setBounds(620,100,80,40);
        backbtn.addActionListener(this);
        backbtn.setFont(f2);
        backbtn.setFocusable(false);
        backbtn.setBorder(BorderFactory.createEmptyBorder(0,0,0,0));
        backbtn.setFocusPainted(true);
        backbtn.setContentAreaFilled(false);
        backbtn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        backbtn.setForeground(Color.white);
        p1.add(backbtn);

        


        img = new ImageIcon("Images/k.png");
        
        imglbl = new JLabel(img);
        imglbl.setBounds(0,0,1000,700);

        iconimg = new ImageIcon("Images/Icon.png");
        this.setIconImage(iconimg.getImage());
        p1.add(imglbl);
        add(p1);
        this.setVisible(true);
        
    }

        public static void main (String args[]){
        new adminAdd();
    }

    public void actionPerformed(ActionEvent e){

        if(e.getSource()==submitbtn){
            
            String first_name = tfname.getText();
            String last_name = tlname.getText();
            String pass = tpass.getText();
            String phn_num = tphnnum.getText();
            String email = temail.getText();

            Boolean bool = false;

           try{
            FileReader file = new FileReader("Datas/User_Data.txt");
            BufferedReader reader = new BufferedReader(file);

            int numberOfLines = 0;
            while(reader.readLine()!=null){
                numberOfLines ++;
            }

            reader.close();

    for(int i = 0 ; i<=numberOfLines;i++){
        String line1 = Files.readAllLines(Paths.get("Datas/User_Data.txt")).get(i);

        if(line1.substring(8).equals(email)){
            bool = true;
            break;
        }
    }
           }catch(Exception ex){
            System.out.println(ex);
           }
           
            

            if(first_name.isEmpty()||last_name.isEmpty()||pass.isEmpty()||phn_num.isEmpty()||email.isEmpty()){
                JOptionPane.showMessageDialog(null,"Please fill all the credentials!!","Error",2);
            }else if(phn_num.length()!=11){
                JOptionPane.showMessageDialog(null,"Please fill the Phone Number Correctly!","Error",2);
            }else if(bool == true){
                JOptionPane.showMessageDialog(null,"Email already exists!","Error",2);
            }else{
                    try{    
                    FileWriter filee = new FileWriter("Datas/User_Data.txt",true);
                    BufferedWriter bfw = new BufferedWriter(filee);
                    PrintWriter pw = new PrintWriter(bfw);
                            
                            pw.println("Email : " + email);
                            pw.println("Password : " + pass);
                            pw.println("Name : " + last_name+","+first_name);
                            pw.println("Phone Number : "+phn_num);
                            pw.println("===============================================");
                            pw.close();
                

                    JOptionPane.showMessageDialog(null,"New User added Succeessfully","TravelBro:)",2);

                    tfname.setText("");
                    tlname.setText("");
                    temail.setText("");
                    tphnnum.setText("");
                    tpass.setText("");
                        this.dispose();
                        new UserData();

                    }
                    catch(Exception ex){
                    System.out.println(ex);
                }
            
            
            
        }   
        }else if(e.getSource()==backbtn){
            this.dispose();
            new UserData();
        }else if(e.getSource()==resetButton){
            this.dispose();
            new adminAdd();
        }
    }
}
